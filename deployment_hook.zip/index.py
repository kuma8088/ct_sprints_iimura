import boto3
import json
import os

codedeploy = boto3.client('codedeploy')

def lambda_handler(event, context):
    print("Entering Lifecycle Hook!")
    print(json.dumps(event))

    deployment_id = event.get('DeploymentId')
    lifecycle_event_hook_execution_id = event.get('LifecycleEventHookExecutionId')

    if not deployment_id or not lifecycle_event_hook_execution_id:
        print("No DeploymentId or LifecycleEventHookExecutionId found. Exiting.")
        return

    params = {
        'deploymentId': deployment_id,
        'lifecycleEventHookExecutionId': lifecycle_event_hook_execution_id,
        'status': 'Succeeded' # 検証成功としてマーク
    }

    try:
        response = codedeploy.put_lifecycle_event_hook_execution_status(**params)
        print("Successfully reported status Succeeded")
        return response
    except Exception as e:
        print(f"Failed to report status: {e}")
        raise e
